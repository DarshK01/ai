/*
 * Program 1: Compute FIRST set of a given grammar
 * Handles direct terminal productions and chained non-terminals
 * Example production format: E=TR  (means E -> TR)
 */
#include <stdio.h>
#include <ctype.h>

char production[10][10];
int n;

void findFirst(char c) {
    int i;
    /* If terminal, it is in FIRST */
    if (!isupper(c)) {
        printf("%c ", c);
        return;
    }
    /* Search all productions with this non-terminal on LHS */
    for (i = 0; i < n; i++) {
        if (production[i][0] == c) {
            if (!isupper(production[i][2]))
                printf("%c ", production[i][2]);
            else
                findFirst(production[i][2]);
        }
    }
}

int main() {
    int i;
    char c;
    printf("Enter number of productions: ");
    scanf("%d", &n);
    printf("Enter productions (Example: E=TR):\n");
    for (i = 0; i < n; i++)
        scanf("%s", production[i]);
    printf("Enter non-terminal to find FIRST: ");
    scanf(" %c", &c);
    printf("FIRST(%c) = { ", c);
    findFirst(c);
    printf("}\n");
    return 0;
}
