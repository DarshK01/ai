/*
 * Program 4: Shift-Reduce Parser
 * Grammar: E -> E+E | E*E | id
 *
 * FIX: Original only reduced "id->E" and had an infinite loop risk.
 *      Fixed to also reduce E+E->E and E*E->E, with proper loop termination.
 */
#include <stdio.h>
#include <string.h>

char stack[50];
int top = -1;

void push(char c) {
    stack[++top] = c;
    stack[top + 1] = '\0';
}

/* Try to find and apply a reduction. Returns 1 if reduced, 0 otherwise. */
int tryReduce(char *remaining) {
    /* Reduce: E op E -> E  (where op is + or *) */
    if (top >= 2) {
        char r = stack[top];
        char op = stack[top - 1];
        char l = stack[top - 2];
        if (l == 'E' && (op == '+' || op == '*') && r == 'E') {
            top -= 3;
            push('E');
            printf("%-20s %-20s REDUCE E->E%cE\n", stack, remaining, op);
            return 1;
        }
    }
    /* Reduce: id -> E */
    if (top >= 1 && stack[top - 1] == 'i' && stack[top] == 'd') {
        top -= 2;
        push('E');
        printf("%-20s %-20s REDUCE E->id\n", stack, remaining);
        return 1;
    }
    return 0;
}

int main() {
    char input[50];
    int i = 0;
    top = -1;
    stack[0] = '\0';

    printf("Enter string (e.g., id+id*id): ");
    scanf("%s", input);
    printf("\n%-20s %-20s ACTION\n", "STACK", "INPUT");
    printf("%-20s %-20s ------\n", "-----", "-----");

    while (1) {
        /* Keep reducing before next shift */
        while (tryReduce(input + i));

        /* If input exhausted, stop */
        if (input[i] == '\0') break;

        /* Shift next symbol */
        push(input[i]);
        stack[top + 1] = '\0';
        printf("%-20s %-20s SHIFT %c\n", stack, input + i + 1, input[i]);
        i++;
    }

    /* Final reductions */
    while (tryReduce(""));

    if (top == 0 && stack[0] == 'E')
        printf("\nString Accepted!\n");
    else
        printf("\nString Rejected!\n");

    return 0;
}
