/*
 * Program 13: Simple Code Generation
 * Input : assignment expression like a=b+c*d
 * Output: Assembly-like target code using register R0
 *
 * FIX: Original loop also started at i=0 but the = handler read exp[i+1],
 *      so the loop was correct structurally, but did not handle the case
 *      where the next char after an operator is also checked properly.
 *      Added bounds check (i+1 < len) to prevent out-of-bounds reads.
 */
#include <stdio.h>
#include <string.h>

int main() {
    char exp[50];
    int i, len;

    printf("Enter expression (e.g., a=b+c*d): ");
    scanf("%s", exp);
    len = strlen(exp);

    printf("\nGenerated Target Code:\n");
    printf("----------------------\n");

    for (i = 0; i < len; i++) {
        if (i + 1 >= len) break; /* safety: no operand after last char */
        switch (exp[i]) {
            case '=':
                printf("MOV R0, %c\n", exp[i + 1]);
                break;
            case '+':
                printf("ADD R0, %c\n", exp[i + 1]);
                break;
            case '-':
                printf("SUB R0, %c\n", exp[i + 1]);
                break;
            case '*':
                printf("MUL R0, %c\n", exp[i + 1]);
                break;
            case '/':
                printf("DIV R0, %c\n", exp[i + 1]);
                break;
        }
    }
    /* Store result back into LHS variable */
    printf("MOV %c, R0\n", exp[0]);
    return 0;
}
