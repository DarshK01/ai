/*
 * Program 2: Symbol Table Implementation
 * Stores identifier name, type, and auto-assigned address
 */
#include <stdio.h>
#include <string.h>

struct symbol {
    char name[20];
    char type[10];
    int address;
};

int main() {
    struct symbol table[20];
    int n, i;
    printf("Enter number of identifiers: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        printf("\nEnter name: ");
        scanf("%s", table[i].name);
        printf("Enter type: ");
        scanf("%s", table[i].type);
        table[i].address = 1000 + i * 4;
    }
    printf("\nSYMBOL TABLE\n");
    printf("%-15s %-10s %s\n", "Name", "Type", "Address");
    printf("%-15s %-10s %s\n", "----", "----", "-------");
    for (i = 0; i < n; i++)
        printf("%-15s %-10s %d\n", table[i].name, table[i].type, table[i].address);
    return 0;
}
