# Compiler Design Practical Programs

A collection of C and Lex/Yacc programs covering core compiler design concepts.

## Repository Structure

```
compiler_design/
├── c_programs/
│   ├── first_of_grammar.c            # Program 1  - FIRST set computation
│   ├── symbol_table.c                # Program 2  - Symbol table
│   ├── three_address_code.c          # Program 3  - Three address code generation
│   ├── sr_parser.c                   # Program 4  - Shift-Reduce parser
│   ├── operator_precedence_parser.c  # Program 5  - Operator precedence parser
│   ├── constant_folding.c            # Program 6  - Code optimization
│   └── code_generation.c             # Program 13 - Target code generation
├── lex_programs/
│   ├── keyword.l                     # Program 8  - Keyword/Identifier/Number
│   ├── digit.l                       # Program 9  - Digit checker
│   ├── count.l                       # Program 10 - Line/Space/Tab counter
│   ├── word.l                        # Program 11 - Word counter
│   └── vowel.l                       # Program 12 - Vowel & consonant counter
└── yacc_programs/
    ├── calc.l                        # Program 7  - Lexer for calculator
    └── calc.y                        # Program 7  - Parser for calculator
```

## How to Compile & Run

### C Programs
```bash
gcc first_of_grammar.c -o first_of_grammar && ./first_of_grammar
gcc symbol_table.c -o symbol_table && ./symbol_table
gcc three_address_code.c -o three_address_code && ./three_address_code
gcc sr_parser.c -o sr_parser && ./sr_parser
gcc operator_precedence_parser.c -o operator_precedence_parser && ./operator_precedence_parser
gcc constant_folding.c -o constant_folding && ./constant_folding
gcc code_generation.c -o code_generation && ./code_generation
```

### Lex Programs
```bash
lex keyword.l && gcc lex.yy.c -o keyword -lfl && ./keyword
lex digit.l   && gcc lex.yy.c -o digit   -lfl && ./digit
lex count.l   && gcc lex.yy.c -o count   -lfl && ./count
lex word.l    && gcc lex.yy.c -o word    -lfl && ./word
lex vowel.l   && gcc lex.yy.c -o vowel   -lfl && ./vowel
```

### Lex + Yacc Calculator (Program 7)
```bash
cd yacc_programs
yacc -d calc.y        # generates y.tab.c and y.tab.h
lex calc.l            # generates lex.yy.c
gcc y.tab.c lex.yy.c -o calc -lfl
./calc
```

## Programs Summary

| # | File | Concept | Input Example |
|---|------|---------|---------------|
| 1 | first_of_grammar.c | FIRST set of a grammar | Productions: E=TR, T=id |
| 2 | symbol_table.c | Symbol table with name, type, address | x, int |
| 3 | three_address_code.c | TAC with operator precedence | a+b*c-d |
| 4 | sr_parser.c | Shift-Reduce parsing | id+id*id |
| 5 | operator_precedence_parser.c | Operator precedence parsing | a+b*c |
| 6 | constant_folding.c | Compile-time constant evaluation | (demo) |
| 7 | calc.l / calc.y | Full calculator via Lex and Yacc | 3+5*2 |
| 8 | keyword.l | Token classification | int x = 10; |
| 9 | digit.l | Digit recognition | 5, a |
| 10 | count.l | Count lines, spaces, tabs | any text |
| 11 | word.l | Word counter | any sentence |
| 12 | vowel.l | Vowel/consonant counter | any string |
| 13 | code_generation.c | Assembly-like code generation | a=b+c*d |

## Bugs Fixed from Original

| Program | Issue | Fix Applied |
|---------|-------|-------------|
| 3 (TAC) | Replaced exp[i+1] with char 't', breaking multi-operator expressions | Rewrote using string-based temp names t1, t2, ... |
| 4 (SR Parser) | Only reduced id->E, missing E+E->E and E*E->E; loop could infinite-loop | Added full reduction rules and proper termination |
| 7 (calc.y) | yyerror() had wrong signature; missing yylex() forward declaration | Fixed to yyerror(const char *s), added declarations |
| 13 (Code Gen) | No bounds check on operator lookahead (i+1) | Added bounds check with switch statement |
