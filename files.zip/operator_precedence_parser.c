/*
 * Program 5: Operator Precedence Parser
 * Parses arithmetic expressions using precedence climbing
 * Operators: + - * /
 */
#include <stdio.h>
#include <string.h>

char stack[50];
int top = -1;

void push(char c) {
    stack[++top] = c;
    stack[top + 1] = '\0';
}

void pop() {
    if (top >= 0) top--;
    stack[top + 1] = '\0';
}

int isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

int precedence(char op) {
    if (op == '*' || op == '/') return 2;
    if (op == '+' || op == '-') return 1;
    return 0;
}

int main() {
    char input[50];
    int i = 0;
    printf("Enter expression (e.g., a+b*c): ");
    scanf("%s", input);

    push('$');
    printf("\n%-25s ACTION\n", "STACK");
    printf("%-25s ------\n", "-----");

    while (input[i] != '\0') {
        char cur = input[i];
        if (!isOperator(cur)) {
            /* Operand: push directly */
            push(cur);
            printf("%-25s Shift %c\n", stack, cur);
        } else {
            /* Reduce while top operator has >= precedence */
            while (top > 0 && isOperator(stack[top]) &&
                   precedence(stack[top]) >= precedence(cur)) {
                char op = stack[top]; pop();
                char right = stack[top]; pop();
                char left  = stack[top]; pop();
                push('E');
                printf("%-25s Reduce: E = %c %c %c\n", stack, left, op, right);
            }
            push(cur);
            printf("%-25s Shift %c\n", stack, cur);
        }
        i++;
    }

    /* Reduce remaining operators */
    while (top > 1 && isOperator(stack[top - 1])) {
        char op    = stack[top - 1];
        char right = stack[top];   pop();
        pop(); /* remove op */
        char left  = stack[top];   pop();
        push('E');
        printf("%-25s Reduce: E = %c %c %c\n", stack, left, op, right);
    }

    printf("\nParsing Completed Successfully!\n");
    return 0;
}
