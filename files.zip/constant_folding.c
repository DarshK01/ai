/*
 * Program 6: Code Optimization - Constant Folding
 * Demonstrates compile-time evaluation of constant expressions
 */
#include <stdio.h>

int main() {
    printf("=== Code Optimization: Constant Folding ===\n\n");

    printf("Original Expression:\n");
    printf("  x = 2 + 3 * 4\n\n");

    printf("Step 1 - Fold multiplication (3 * 4 = 12):\n");
    printf("  x = 2 + 12\n\n");

    printf("Step 2 - Fold addition (2 + 12 = 14):\n");
    int result = 2 + 3 * 4;
    printf("  x = %d\n\n", result);

    printf("Optimized Code (no runtime computation needed):\n");
    printf("  x = %d\n", result);

    return 0;
}
