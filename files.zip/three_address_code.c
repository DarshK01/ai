/*
 * Program 3: Three Address Code Generation
 * Supports single-char operand expressions like: a+b*c-d
 * Handles operator precedence (* and / before + and -)
 *
 * FIX: Original code replaced exp[i+1] with 't' char which broke
 *      multi-operator expressions. Fixed using proper temp-name strings.
 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int temp = 1;

/* Find index of highest-precedence operator in expression */
int findOp(char *exp) {
    int i, len = strlen(exp);
    /* First look for * or / */
    for (i = 0; i < len; i++)
        if (exp[i] == '*' || exp[i] == '/')
            return i;
    /* Then + or - */
    for (i = 0; i < len; i++)
        if (exp[i] == '+' || exp[i] == '-')
            return i;
    return -1;
}

void generateTAC(char *exp) {
    int opIdx;
    char newexp[100];
    char tname[8];

    while ((opIdx = findOp(exp)) != -1) {
        char lop = exp[opIdx - 1];
        char op  = exp[opIdx];
        char rop = exp[opIdx + 1];

        sprintf(tname, "t%d", temp);
        printf("%s = %c %c %c\n", tname, lop, op, rop);

        /* Rebuild expression: replace lop op rop with tname */
        char before[100] = {0};
        strncat(before, exp, opIdx - 1);
        strcat(before, tname);
        strcat(before, exp + opIdx + 2);
        strcpy(exp, before);

        temp++;
    }
}

int main() {
    char exp[100];
    printf("Enter expression (e.g., a+b*c-d): ");
    scanf("%s", exp);
    printf("\nThree Address Code:\n");
    generateTAC(exp);
    printf("Final result stored in t%d\n", temp - 1);
    return 0;
}
