/* Program 7: Yacc grammar for Simple Calculator
 *
 * FIX: Added forward declaration of yylex().
 *      Fixed yyerror() signature to match POSIX standard: (const char *s).
 *      Added division-by-zero check.
 *      Added start rule to print result.
 */
%{
#include <stdio.h>
#include <stdlib.h>

int yylex(void);
int yyerror(const char *s);
%}

%token NUMBER

%%
start : expr { printf("Result = %d\n", $1); }
      ;

expr  : expr '+' term { $$ = $1 + $3; }
      | expr '-' term { $$ = $1 - $3; }
      | term          { $$ = $1; }
      ;

term  : term '*' factor { $$ = $1 * $3; }
      | term '/' factor {
            if ($3 == 0) {
                fprintf(stderr, "Error: Division by zero\n");
                exit(1);
            }
            $$ = $1 / $3;
        }
      | factor          { $$ = $1; }
      ;

factor : NUMBER { $$ = $1; }
       ;
%%

int main() {
    printf("Enter expression: ");
    yyparse();
    return 0;
}

int yyerror(const char *s) {
    fprintf(stderr, "Parse Error: %s\n", s);
    return 1;
}
